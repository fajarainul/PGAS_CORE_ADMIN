<?php
	$hostname 	= "localhost";
	$username 	= "root";
	$dbname		= "pgascore";
	$password	= "";
?>